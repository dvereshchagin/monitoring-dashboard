# Security Policy

## Supported Versions

The latest version of templ is supported.

## Reporting a Vulnerability

Use the "Security" tab in GitHub and fill out the "Report a vulnerability" form.
