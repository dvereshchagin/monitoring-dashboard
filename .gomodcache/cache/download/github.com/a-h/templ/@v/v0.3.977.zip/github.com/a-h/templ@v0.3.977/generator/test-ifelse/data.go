package ifelse

type data struct {
}

func (d data) IsTrue() bool {
	return false
}
