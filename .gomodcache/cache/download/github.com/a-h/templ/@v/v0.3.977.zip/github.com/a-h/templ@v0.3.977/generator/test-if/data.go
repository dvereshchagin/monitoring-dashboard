package testif

type data struct {
}

func (d data) IsTrue() bool {
	return true
}
