// SPDX-FileCopyrightText: 2018 The Go Language Server Authors
// SPDX-License-Identifier: BSD-3-Clause

package protocol

// Version is the version of the language-server-protocol specification being implemented.
const Version = "3.15.3"
