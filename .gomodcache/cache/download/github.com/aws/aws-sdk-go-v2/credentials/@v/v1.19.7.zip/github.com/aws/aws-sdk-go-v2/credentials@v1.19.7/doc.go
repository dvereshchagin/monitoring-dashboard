/*
Package credentials provides types for retrieving credentials from credentials sources.
*/
package credentials
